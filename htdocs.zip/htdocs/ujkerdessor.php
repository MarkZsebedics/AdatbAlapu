<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Új kérdessorok</title>
    <meta name="author" content="Dobó Csenge, Tajti Sándor, Zsebedics Márk"/>
    <link rel="icon" href="images/logo.png"/>
    <link rel=stylesheet type="text/css" href="style/ujkerdesek_style.css" />
    <?php include "php/ujkerdessor.php";
    $difErr = $soqNameErr = '';?>

</head>
<body>
<header>
    <nav class="box" id="navigation">
        <ul>
            <li class="mainbtn"><a href = main.php target="_self">Főoldal</a></li>
            <li class="kerdessorbtn"><a href = kerdessorok.php target="_self">Quiz</a></li>
            <li class="szobabtn"><a href = szobak.php target="_self">Játék szobák</a></li>
            <li class="versenybtn"><a href = versenyek.php target="_self">Versenyek</a></li>
            <li class="forumbtn"><a href = forum.php target="_self">Forum</a></li>
            <li class="felhasznalobtn"><a href = felhasznalo.php target="_self">Profil</a></li>
            <li class="ranglistabtn"><a href = ranglista.php target="_self">Ranglista</a></li>
            <li class="logoutbtn"><a href = php/logout.php target="_self">Kijelentkezés</a></li>
        </ul>
    </nav>
</header>
<div class="ujkerdesek">
    <form method="post">
        Kérdéssor neve: <input type="text" name="soq_name" required>
        <span class="error"><?php echo $soqNameErr;?></span>
        <br><br>
        Kérdések száma: <input type="number" name="count" required>
        <br><br>
        Téma : <input type="text" name="theme" required>
        <br><br>
        Nehézség:
        <br>
        <input type="radio" id="easy" name="dif" value="easy" >
        <label for="easy">Könnyű </label><br>
        <input type="radio" id="med" name="dif" value="med" >
        <label for="med">Közepes </label><br>
        <input type="radio" id="hard" name="dif" value="hard" >
        <label for="hard">Nehéz </label><br>
        <input type="radio" id="vhard" name="dif" value="vhard" >
        <label for="med">Nagyon nehéz </label><br>
        <input type="radio" id="vvhard" name="dif" value="vvhard" >
        <label for="hard">Csontzene és patakvér </label><br>
        <span class="error"><?php echo $difErr;?></span><br>
        Más nehézség : <input type="text" name="dif2">
        <br><br>
        <button class="kerdessorbtn" type="submit">Tovább</button><br>
    </form>
</div>
<footer>Az alábbi Adatbázis alapú rendszerek gyakorlat projektmunka egy quiz webes felületének működését reprezentálja.<br> Készítette: Dobó Csenge, Tajti Sándor, Zsebedics Márk</footer>
</body>
</html>