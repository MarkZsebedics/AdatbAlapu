<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Játék szobák</title>
    <meta name="author" content="Dobó Csenge, Tajti Sándor, Zsebedics Márk"/>
    <link rel="icon" href="images/logo.png"/>
    <link rel=stylesheet type="text/css" href="style/szoba_style.css" />
</head>
<body>
<nav class="box" id="navigation">
    <ul>
        <li class="mainbtn"><a href = main.php target="_self">Főoldal</a></li>
        <li class="kerdessorbtn"><a href = kerdessorok.php target="_self">Quiz</a></li>
        <li class="szobabtn"><a href = szobak.php target="_self">Játék szobák</a></li>
        <li class="versenybtn"><a href = versenyek.php target="_self">Versenyek</a></li>
        <li class="forumbtn"><a href = forum.php target="_self">Forum</a></li>
        <li class="felhasznalobtn"><a href = felhasznalo.php target="_self">Profil</a></li>
        <li class="ranglistabtn"><a href = ranglista.php target="_self">Ranglista</a></li>
        <li class="logoutbtn"><a href = php/logout.php target="_self">Kijelentkezés</a></li>
    </ul>
</nav>
<div class="phpstyle">
<?php include "php/szobak.php" ?>
</div>
</body>
</html>