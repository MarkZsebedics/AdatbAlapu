<?php
include 'connection.php';

if(!isset($_SESSION['id'])){
    echo "<script> location.href='bejelentkezes.php'; </script>";
    exit;
}
$roomNameErr = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["room_name"])) {
        $conn = OpenCon();

        $stid = oci_parse($conn, "SELECT NEV FROM SZOBA WHERE NEV = '" . $_POST["room_name"] . "'");
        oci_execute($stid);
        $row = oci_fetch_array($stid, OCI_BOTH);

        if (!isset($row['NEV']))  {
            $stid = oci_parse($conn, "SELECT FELHASZNALONEV FROM FELHASZNALO WHERE FELHASZNALOAZON = " . $_SESSION["id"]);
            oci_execute($stid);
            $row = oci_fetch_array($stid, OCI_BOTH);

            $stid = oci_parse($conn, "UPDATE SZOBA SET NEV = '" .  $_POST["room_name"] . "' WHERE SZOBAAZON = " .  $_GET["id"]);
            oci_execute($stid);
            echo "<script> location.href='szobak.php'; </script>";
            exit;
        } else {
            $roomNameErr = "A szoba már létezik!";
        }
        CloseCon($conn);
    }
}

