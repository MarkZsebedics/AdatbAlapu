<?php


include 'connection.php';

$usernameErr = $pwErr = $pw2Err = $equErr = "";
$username = $pw2 = $pw = $bornDate =  $addressErr = $bornDateErr = "";
$email = "-";
$done = 0;

if (array_key_exists("pw2", $_POST) && array_key_exists("pw", $_POST)) {
    if ($_POST["pw2"] == $_POST["pw"]) {
        $equErr = "";
    } else {
        $equErr = "A jelszavak nem egyeznek.";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["username"])) {
        $usernameErr = "Kötelező kitölteni!";
    } else {
        $conn = OpenCon();

        $stid = oci_parse($conn, "SELECT FELHASZNALONEV FROM FELHASZNALO WHERE FELHASZNALO.FELHASZNALONEV = '" . $_POST["username"] . "'");
        oci_execute($stid);
        $row = oci_fetch_array($stid, OCI_BOTH);
        if (!isset($row['FELHASZNALONEV'])) {
            $username = $_POST["username"];
            $done++;
        } else {
            $usernameErr = "A felhasználónév már létezik!";
        }
        CloseCon($conn);
    }

    if (empty($_POST["pw"])) {
        $pwErr = "Kötelező kitölteni";
    } else {
        $pw = $_POST["pw"];
        $done++;
    }

    if (empty($_POST["pw2"])) {
        $pw2Err = "Kötelező kitölteni";
    } else {
        $done++;
    }

    if (empty($_POST["bornDate"])) {
        $bornDateErr = "Kötelező kitölteni";
    } else {
        $bornDate = date('Y-m-d', strtotime($_POST['bornDate']));
        $done++;
    }

    if (empty($_POST["addressM"]) || empty($_POST["addressV"])) {
        $addressErr = "Mind a két mezőt ki kell tölteni!";
    } else {
        $done++;
    }

    if (empty($_POST["email"])) {
        $emailErr = "Kötelező kitölteni";
    } else {
        $conn = OpenCon();

        $stid2 = oci_parse($conn, "SELECT EMAIL FROM FELHASZNALO WHERE FELHASZNALO.EMAIL = '" . $_POST["email"] . "'");
        oci_execute($stid2);
        $row2 = oci_fetch_array($stid2, OCI_BOTH);
        if (!isset($row2['email'])) {
            $email = $_POST['email'];
            $done++;
        } else {
            $emailErr = "Az email cím foglalt!";
        }
        CloseCon($conn);
    }

    if ($done == 6) {
        $addressID = 0;

        $conn = OpenCon();

        $stid = oci_parse($conn, "SELECT MEGYE, VAROS, LAKHELYAZON FROM LAKHELY WHERE LAKHELY.MEGYE = '" . $_POST["addressM"] . "' AND LAKHELY.VAROS = '" . $_POST["addressV"] . "'");
        oci_execute($stid);
        $row = oci_fetch_array($stid, OCI_BOTH);

        if (isset($row['MEGYE'])) {
            $addressID = $row["LAKHELYAZON"];
        } else {
            $stid = oci_parse($conn, "INSERT INTO LAKHELY (MEGYE, VAROS) VALUES ('" . $_POST["addressM"] . "', '" . $_POST["addressV"] . "')");
            oci_execute($stid);

            $stid = oci_parse($conn, "SELECT MAX(LAKHELYAZON) AS lakhely FROM LAKHELY");
            oci_execute($stid);
            $row = oci_fetch_array($stid, OCI_BOTH);
            $addressID = $row['LAKHELY'];
        }

        $conn = OpenCon();

        $stid2 = oci_parse($conn, "INSERT INTO FELHASZNALO (JELSZO, EMAIL, SZULDATUM, LAKHELYAZON, FELHASZNALONEV) VALUES ('" . $pw . "', '" . $email . "', TO_DATE('".$bornDate."','yyyy-mm-dd'), " . $addressID . ", '" . $username . "')");
        oci_execute($stid2);

        CloseCon($conn);
        echo "<script> location.href='bejelentkezes.php'; </script>";
    }
}
