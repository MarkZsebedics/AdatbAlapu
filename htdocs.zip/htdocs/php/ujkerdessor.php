<?php

include 'connection.php';

if(!isset($_SESSION['id'])){
    echo "<script> location.href='bejelentkezes.php'; </script>";
    exit;
}
$soqName = $dif = '';
$soqNameErr = $difErr = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["soq_name"])) {
        $conn = OpenCon();

        $stid = oci_parse($conn, "SELECT NEV FROM KERDESSOR WHERE NEV = '" . $_POST["soq_name"] . "'");

        oci_execute($stid);

        $row = oci_fetch_array($stid, OCI_BOTH);

        if (!isset($row['NEV']))  {
            $soqName = $_POST["soq_name"];
        } else {
            $soqNameErr = "A kérdéssor már létezik!";
        }
        CloseCon($conn);
    }

    $_SESSION['count'] = $_POST['count'];

    if (empty($_POST["dif"]) && empty($_POST["dif2"])) {
        $difErr = "Adj meg nehézségi szintet!";
    } elseif (empty($_POST["dif"])) {
        $conn = OpenCon();

        $stid = oci_parse($conn, "INSERT INTO NEHEZSEG (NEV) VALUES ('" . $_POST["dif2"] . "')");

        if (oci_execute($stid) === TRUE) {
            $stid = oci_parse($conn, "SELECT MAX(NEHEZSEGAZON) AS id FROM NEHEZSEG");
            oci_execute($stid);
            $row = oci_fetch_array($stid, OCI_BOTH);
            $dif = $row['ID'];
        }

        CloseCon($conn);
    } else {
        $dif = $_POST["dif"];
        switch ($dif) {
            case "easy": $dif = 1; break;
            case "med": $dif = 2; break;
            case "hard": $dif = 3; break;
            case "vhard": $dif = 4; break;
            case "vvhard": $dif = 5; break;
        }
    }

    if ($dif != '' && $soqName != '') {

        $conn = OpenCon();

        $stid = oci_parse($conn, "INSERT INTO KERDESSOR (NEV, NEHEZSEGAZON, OSSZPONT) VALUES ('" . $soqName . "', " . $dif . ", " . $_SESSION['count'] . ")");

        $_SESSION['soqName'] = $soqName;

        if (oci_execute($stid)) {

            $stid = oci_parse($conn, "SELECT MAX(KERDESSORAZON) AS id FROM KERDESSOR");
            oci_execute($stid);
            $row = oci_fetch_array($stid, OCI_BOTH);
            $id = $row['ID'];

            $stid = oci_parse($conn, "SELECT * FROM TEMA WHERE TEMA.NEV = '" . $_POST['theme'] . "'");
            oci_execute($stid);
            $row = oci_fetch_array($stid, OCI_BOTH);

            if (isset($row['TEMAAZON'])) {
                $stid = oci_parse($conn, "INSERT INTO KERDESSORTEMAJA (KERDESSORAZON, TEMAAZON) VALUES (" . $id . ", " . $row['TEMAAZON'] . ")");
                oci_execute($stid);

            } else {
                $stid = oci_parse($conn, "INSERT INTO TEMA (NEV) VALUES ('" . $_POST['theme'] . "')");

                if (oci_execute($stid) === TRUE) {
                    $stid = oci_parse($conn, "SELECT MAX(TEMAAZON) AS id FROM TEMA");
                    oci_execute($stid);
                    $row = oci_fetch_array($stid, OCI_BOTH);
                    $id2 = $row['ID'];

                    $stid = oci_parse($conn, "INSERT INTO KERDESSORTEMAJA (KERDESSORAZON, TEMAAZON) VALUES ('" . $id . "', '" . $id2. "')");
                    oci_execute($stid);

                } else {
                    echo "Nem sikerült!<br>";
                }
            }

            echo "<script> location.href='ujkerdesek.php'; </script>";

        } else {
            echo "Nem sikerült!<br>";
        }

        CloseCon($conn);
    }
}