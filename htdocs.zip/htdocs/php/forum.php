<?php

include 'connection.php';

$conn = OpenCon();

$stid = oci_parse($conn, "SELECT FORUMBEJEGYZES.BEJEGYZESAZON AS id, FORUMBEJEGYZES.SZOVEG AS text,
FORUMBEJEGYZES.FELHASZNALOAZON, FELHASZNALO.FELHASZNALONEV AS username, FELHASZNALO.FELHASZNALOAZON,
TEMA.TEMAAZON, TEMA.NEV AS theme, BEJEGYZESTEMAJA.BEJEGYZESAZON, BEJEGYZESTEMAJA.TEMAAZON
FROM FORUMBEJEGYZES, TEMA, FELHASZNALO, BEJEGYZESTEMAJA WHERE
FORUMBEJEGYZES.FELHASZNALOAZON = FELHASZNALO.FELHASZNALOAZON AND
FORUMBEJEGYZES.BEJEGYZESAZON = BEJEGYZESTEMAJA.BEJEGYZESAZON AND
TEMA.TEMAAZON = BEJEGYZESTEMAJA.TEMAAZON");

oci_execute($stid);
$i = 1;
echo '<div class="forum2">';
echo '<form method="post">';

while (($row = oci_fetch_array($stid, OCI_BOTH))!= false){

    echo '<fieldset class="soq">';
    echo $i . '. Bejegyzés témája: ' . $row['THEME'] . '<br><br><br>' . $row['TEXT'] . '<br><br><br>Készítője: ' . $row['USERNAME'] . '<br><br>';
    echo '<a class="fill-in" href="torles.php?id=' . $row['ID'] . '">Bejegyzés törlése</a>';
    echo '</fieldset>';
    $i++;
}

echo '</form>';
echo '</div>';

echo '<div class="forum">';
echo '<form method="post">';
echo '<fieldset class="soq">';
echo '<a>Írj te is bejegyzést: </a><br><br>';
echo '<a>Téma: </a><br>';
echo '<input type="text" size="20dp" name="theme"  required><br>';
echo '<a>Szöveg:  </a><br>';
echo '<input type="text" size="80dp" name="text"  required><br>';
echo '<button type="submit" >Küldés</button>';
echo '</fieldset>';
echo '</form>';
echo '</div>';

if(isset($_POST["text"]) && isset($_POST["theme"]) && isset($_SESSION['id'])) {

    echo $_POST["theme"];

    $stid = oci_parse($conn, "INSERT INTO FORUMBEJEGYZES (SZOVEG, FELHASZNALOAZON) VALUES ('" . $_POST["text"] . "', " . $_SESSION['id'] . ")");

    if (oci_execute($stid) === TRUE) {
        $stid = oci_parse($conn, "SELECT NEV, TEMAAZON FROM TEMA WHERE NEV = '" . $_POST["theme"] . "'");
        oci_execute($stid);
        $row = oci_fetch_array($stid, OCI_BOTH);

        $stid2 = oci_parse($conn, "SELECT MAX(BEJEGYZESAZON) AS id FROM FORUMBEJEGYZES");
        oci_execute($stid2);
        $row2 = oci_fetch_array($stid2, OCI_BOTH);
        $forumID = $row2['ID'];

        if (!isset($row['NEV'])) {
            $stid = oci_parse($conn, "INSERT INTO TEMA (NEV) VALUES ('" . $_POST["theme"] . "')");

            if (oci_execute($stid) === TRUE) {
                $stid = oci_parse($conn, "SELECT MAX(TEMAAZON) AS id FROM TEMA");
                oci_execute($stid);
                $row = oci_fetch_array($stid, OCI_BOTH);
                $temaID = $row['ID'];

                if (isset($row['ID'])) {

                    $stid = oci_parse($conn, "INSERT INTO BEJEGYZESTEMAJA (BEJEGYZESAZON, TEMAAZON) VALUES (" . $forumID . ", " . $temaID . ")");
                    oci_execute($stid);

                    echo "<script> location.href='forum.php'; </script>";
                    exit;
                }
            }

        } else {
            $stid = oci_parse($conn, "INSERT INTO BEJEGYZESTEMAJA (BEJEGYZESAZON, TEMAAZON) VALUES (" . $forumID . ", " . $row['TEMAAZON'] . ")");
            oci_execute($stid);
            echo "<script> location.href='forum.php'; </script>";
            exit;
        }
    } elseif (isset($_POST["text"]) && isset($_POST['text']) && !isset($_SESSION['id'])) {
        echo "<script> location.href='bejelentkezes.php'; </script>";
        exit;
    }
}

CloseCon($conn);

