<?php

 session_start();
 unset($_SESSION['id']);
 header('Location: ../main.php');// user is redirected to the sign up page.
