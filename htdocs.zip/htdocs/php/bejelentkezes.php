<?php

if(isset($_POST['Submit'])){

    include 'connection.php';
    $conn = OpenCon();

    if ($_POST['userName'] == '' || $_POST['password'] == '') {
        $msg="<span style='color:red'>Kérlek adj meg felhasználó nevet és a jelszót!</span>";
    }

    $stid = oci_parse($conn, "SELECT JELSZO, FELHASZNALONEV, FELHASZNALOAZON FROM FELHASZNALO WHERE FELHASZNALONEV = '" . $_POST['userName'] . "'");

    if((oci_execute($stid)) === TRUE) {
        $row = oci_fetch_array($stid, OCI_BOTH);

        if ($row['JELSZO'] === $_POST['password'] && $row['FELHASZNALONEV'] === $_POST['userName']) {

            $_SESSION['id']= $row['FELHASZNALOAZON'];
            echo "<script> location.href='felhasznalo.php'; </script>";
            CloseCon($conn);
            exit;

        } else {
            $msg = "<span style='color:red'>Helytelen felhasználónév vagy jelszó</span>";
        }
    } else {
        $msg = "<span style='color:red'>Helytelen felhasználónév vagy jelszó</span>";
    }

    CloseCon($conn);
}
?>