<?php

include 'connection.php';

$conn = OpenCon();



echo '<div class="ranglista">';
echo '<h1>Ranglista: </h1><br>';
echo '</div>';


echo "<br>";

$ss = oci_parse($conn, "
select cast(avg(eredmeny.pontszam) as numeric(36,2)) as ATLAG,tema.nev as nev from tema left outer join 
kerdesSorTemaja on tema.temaAzon = kerdesSorTemaja.temaAzon
left outer join 
kerdesSor on  kerdesSor.kerdesSorAzon  = kerdesSorTemaja.kerdesSorAzon
left outer join eredmeny 
on kerdesSor.kerdesSorAzon = eredmeny.kerdesSorAzon
group by tema.nev");



oci_execute($ss);

echo '<div class="ranglista">';

echo 'A versenyzok atlaga temankent lebontva:<br> <br>';

while($r = oci_fetch_array($ss, OCI_BOTH)){
    if(!isset($r['ATLAG'])){
        $r['ATLAG'] = '  Nem toltottek meg ki testet';
    }
    echo $r['NEV'] .' - ' .  $r['ATLAG'] . '<br>';
}

echo '</div>';
echo "<br>";

$ss = oci_parse($conn,'select felhasznalo.felhasznalonev as nev , cast(avg(eredmeny.pontszam) as numeric(37,1)) as atlag
from felhasznalo left outer join 
eredmeny on felhasznalo.felhasznaloAzon = eredmeny.felhasznaloAzon
where eredmeny.pontszam is not null
group by felhasznalo.felhasznalonev
order by avg(eredmeny.pontszam) desc');



oci_execute($ss);

echo '<div class="ranglista">';

echo 'Legjobb pontossagu versenyzoink<br> <br>';
while($r = oci_fetch_array($ss, OCI_BOTH)){
    if(!isset($r['ATLAG'])){
        $r['ATLAG'] = 0;
    }
    echo $r['NEV'] . ' - '. $r['ATLAG'] . '%<br>';
}
echo '</div>';
echo "<br>";
$ss = oci_parse($conn,'
select felhasznalo.felhasznalonev as nev, sum(eredmeny.pontszam) as ossz
from felhasznalo left outer join 
eredmeny on felhasznalo.felhasznaloAzon = eredmeny.felhasznaloAzon
where eredmeny.pontszam is not null
group by felhasznalo.felhasznalonev
order by sum(eredmeny.pontszam) desc');

oci_execute($ss);

echo '<div class="ranglista">';

echo 'Legtobb pontot elero versenyzoink<br> <br>';
while($r = oci_fetch_array($ss, OCI_BOTH)){
    if(!isset($r['OSSZ'])){
        $r['OSSZ'] = 0;
    }

    echo $r['NEV'] . ' - '. $r['OSSZ'] . ' pont <br>';
}

echo '</div>';
echo "<br>";

$ss = oci_parse($conn,'select felhasznalo.felhasznalonev as nev, eredmeny.pontszam as pont 
from felhasznalo left outer join 
eredmeny on felhasznalo.felhasznaloAzon = eredmeny.felhasznaloAzon
where eredmeny.kerdesSorAzon = 1');



oci_execute($ss);

echo '<div class="ranglista">';

echo 'A kalkulus bukasok tengere<br> <br>';
while($r = oci_fetch_array($ss, OCI_BOTH)){
    if(!isset($r['PONT'])){
        $r['PONT'] = 0;
    }
    if($r['PONT'] <= 40){
        echo $r['NEV'] . ' user - '. $r['PONT'] . ' pontot ert el kalkulusbol, amivel megbukott<br>';
    }
    else{echo $r['NEV'] . ' user - '. $r['PONT'] . ' pontot ert el, amivel atment<br>';}
}
echo '</div>';
oci_execute($ss);
$ideiEv = date("Y");

echo "<br>";



$ss = oci_parse($conn,"select EXTRACT(YEAR from felhasznalo.szulDatum )as nev, cast(avg(eredmeny.pontszam) as numeric(37,1)) as atlag
from felhasznalo left outer join 
eredmeny on felhasznalo.felhasznaloAzon = eredmeny.felhasznaloAzon
group by EXTRACT(YEAR from felhasznalo.szulDatum )");

echo '<div class="ranglista">';

echo 'Eletkorokra lebontot atlag<br> <br>';
oci_execute($ss);
while($r = oci_fetch_array($ss, OCI_BOTH)){
    if(!isset($r['ATLAG'])){
        $r['ATLAG'] = 0;
    }
    $kor = intval($ideiEv) - intval($r['NEV']);
    echo "A ".$kor." eves userek attlaga: ". $r['ATLAG'] . "<br>";
}

echo '</div>';
echo "<br>";



$ss = oci_parse($conn,"select nehezseg.nev as Nehez, kerdesSor.kerdesSorAzon as azon
from nehezseg, kerdessor
where nehezseg.nehezsegAzon = kerdesSor.nehezsegAzon");

echo '<div class="ranglista">';

echo 'Nehezsegekre lebontot atlag<br> <br>';
oci_execute($ss);
while($r = oci_fetch_array($ss, OCI_BOTH)){
    if(!isset($r['AZON'])){
        continue;
    }
    $side = oci_parse($conn,"select cast(avg(eredmeny.pontszam) as numeric(37,1)) as atlag
        from kerdesSor left outer join eredmeny 
        on kerdesSor.kerdesSorAzon = eredmeny.kerdesSorAzon
        where kerdesSor.kerdesSorAzon =  " . $r['AZON'] .
        "group by kerdesSor.kerdesSorAzon");
    oci_execute($side);
    $rr = oci_fetch_array($side, OCI_BOTH);
    echo "A ".$r['NEHEZ']." szintu kerdessorok kitolteseinek atlaga: ". $rr['ATLAG'] . "<br>";
}

echo '</div>';

CloseCon($conn);
