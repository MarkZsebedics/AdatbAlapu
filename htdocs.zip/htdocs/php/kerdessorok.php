<?php

include 'connection.php';

$conn = OpenCon();

$stid = oci_parse($conn, "SELECT KERDESSOR.KERDESSORAZON AS id, KERDESSOR.NEV AS nev,
KERDESSOR.OSSZPONT AS pont,
NEHEZSEG.NEV AS nehezseg FROM KERDESSOR
INNER JOIN NEHEZSEG ON NEHEZSEG.NEHEZSEGAZON = KERDESSOR.NEHEZSEGAZON");

oci_execute($stid);
$i = 1;

echo '<div class="kerdessorok2">';
echo '<form method="post">';
echo '<fieldset class="soq">';
echo '<a>Hozz létre új kérdéssort: </a><br>';
echo '<a class="fill-in" href="ujkerdessor.php">Új kérdéssor</a>';
echo '</fieldset>';
echo '</form>';
echo '</div>';

while (($row = oci_fetch_array($stid, OCI_BOTH))!= false){

    echo '<div class="kerdessorok">';
    echo '<form method="post">';
    echo '<fieldset class="soq">';
    echo $i . '. ' . $row['NEV'] . '<br><br>';
    echo 'Téma: ';

    $stid2 = oci_parse($conn, "SELECT TEMA.TEMAAZON AS id, TEMA.NEV AS nev,
KERDESSORTEMAJA.TEMAAZON, KERDESSORTEMAJA.KERDESSORAZON AS id FROM TEMA, KERDESSORTEMAJA
WHERE KERDESSORTEMAJA.TEMAAZON = TEMA.TEMAAZON AND KERDESSORTEMAJA.KERDESSORAZON = " . $row['ID']);

    oci_execute($stid2);

    while (($row2 = oci_fetch_array($stid2, OCI_BOTH))!= false){
        echo "[" . $row2['NEV'] . "] ";
    }

    echo '<br><br>';
    echo 'Nehézség: ' . $row['NEHEZSEG'] . '<br>Elérhető pontok: ' . $row['PONT'] . '<br><br>';
    echo '<a class="fill-in" href="kerdesek.php?id=' . $row['ID'] . '">Kitöltés</a>';
    echo '</fieldset>';
    echo '</form>';
    echo '</div>';
    $i++;

}

if (isset($_SESSION['soqId'])) {
    $soqId = $_SESSION['soqId'];
    $questionId = '';
    $isRight = 0;

    foreach($_POST as $key => $value){

        if(strpos($key, "question") !== false) {
            $stid = oci_parse($conn, "INSERT INTO KERDES (KERDESSORAZON, NEV, PONTSZAM) VALUES (" . $soqId . ", '" . $value . "', 1)");

            if (oci_execute($stid) === TRUE) {
                $stid = oci_parse($conn, "SELECT MAX(KERDESAZON) AS id FROM KERDES");
                oci_execute($stid);
                $row = oci_fetch_array($stid, OCI_BOTH);
                $questionId = $row['ID'];

            } else {
                echo "Nem sikerült!";
            }
        }
        elseif(strpos($key, "answear") !== false) {

            $stid = oci_parse($conn, "SELECT * FROM VALASZ WHERE NEV = '" . $value . "'");

            oci_execute($stid);

            $row = oci_fetch_array($stid, OCI_BOTH);

            if (isset($row['VALASZAZON'])) {
                $stid = oci_parse($conn, "INSERT INTO KERDESVALASZA (KERDESAZON, VALASZAZON) VALUES ('" . $questionId . "', '" . $row['VALASZAZON'] . "')");

                oci_execute($stid);
            } else {
                if ($isRight == 1) {
                    $stid = oci_parse($conn, "INSERT INTO VALASZ (NEV, HELYESSEG) VALUES ('" . $value . "', 'Y')");
                    $isRight = 0;
                } else {
                    $stid = oci_parse($conn, "INSERT INTO VALASZ (NEV, HELYESSEG) VALUES ('" . $value . "', 'N')");
                }

                if (oci_execute($stid) === TRUE) {
                    $stid = oci_parse($conn, "SELECT MAX(VALASZAZON) AS id FROM VALASZ");
                    oci_execute($stid);
                    $row = oci_fetch_array($stid, OCI_BOTH);
                    $answearId = $row['ID'];

                    $stid = oci_parse($conn, "INSERT INTO KERDESVALASZA (KERDESAZON, VALASZAZON) VALUES ($questionId, $answearId)");

                    if (oci_execute($stid) === FALSE) {
                        echo "Nem sikerült!";
                    }
                } else {
                    echo "Nem sikerült!";
                }
            }
        } else {
            $isRight = 1;
        }
    }

    unset($_SESSION['soqId']);
}

CloseCon($conn);
