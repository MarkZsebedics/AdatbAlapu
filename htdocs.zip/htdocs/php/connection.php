<?php

function OpenCon () {
    $conn = oci_connect('system', 'oracle', 'localhost/XE');
    if (!$conn) {
        $e = oci_error();
        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
    } else {
        return $conn;
    }
}

function CloseCon ($conn) {
    oci_close($conn);
}
?>