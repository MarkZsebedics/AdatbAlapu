<?php

if(!isset($_SESSION['id'])) {
    echo "<script> location.href='bejelentkezes.php'; </script>";
    exit;
} else {
    ListQuestions();
}

function ListQuestions () {

    include 'connection.php';
    $conn = OpenCon();
    $_SESSION['kerdessor'] = $_GET['id'];

    $stid = oci_parse($conn, "SELECT * FROM KERDES WHERE KERDES.KERDESSORAZON = " . $_GET['id']);

    oci_execute($stid);

    $i = 1;
    echo '<div class="kerdesek">';
    echo '<form method="post" action="eredmeny.php">';
    while (($row = oci_fetch_array($stid, OCI_BOTH))!= false) {


        echo '<fieldset>';
        echo $i . '. ' . $row['NEV'] . ' (' . $row['PONTSZAM'] . ' pont)' . '<br>';
        $id = $row['KERDESAZON'];

        $stid2 = oci_parse($conn, "SELECT VALASZ.NEV AS nev, VALASZ.VALASZAZON AS id
                    FROM KERDESVALASZA, VALASZ
                    WHERE KERDESVALASZA.VALASZAZON = VALASZ.VALASZAZON
                    AND KERDESVALASZA.KERDESAZON = " . $id);
        oci_execute($stid2);

        while (($row2 = oci_fetch_array($stid2, OCI_BOTH))!= false) {

            $value = $row2['ID'];
            echo '<input type="radio" id="' . $value .'" name="' . $i . '" value="' . $value . '" >';
            echo '<label for="' . $value . '">' . $row2['NEV'] . '</label><br>';
        }
        echo '</fieldset>';

        $i++;
    }
    echo '<button class="kerdessorbtn" type="submit">Kész</button>';
    echo '</form>';
    echo '</div>';

    CloseCon($conn);
}