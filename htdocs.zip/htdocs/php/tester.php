<?php

include 'connection.php';

$conn = OpenCon();

$s = oci_parse($conn, "SELECT table_name FROM user_tables");
oci_execute($s);
$i = 0;

while (($r = oci_fetch_array($s, OCI_NUM))!= false){

    $stid = oci_parse($conn, "SELECT * FROM " . $r[$i]);

    oci_execute($stid);

    echo "<table border='2'>\n";
    echo "<thead>\n";
    echo "<h1> " . $r[$i] . "</h1>";
    echo "</thead>\n";
    echo "<tbody>\n";
    echo "<tr>\n";
    for ($j = 1; $j <= oci_num_fields($stid); ++$j) {
        echo "<th>" . oci_field_name($stid, $j) . "</th>\n";
    }
    echo "</tr>\n";
    while (($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS))) {
        echo "<tr>\n";
        foreach ($row as $item) {
            echo "    <td>" . ($item !== null ? htmlentities($item, ENT_QUOTES) : "&nbsp;") . "</td>\n";
        }
        echo "</tr>\n";
    }
    echo "</tbody>\n";
    echo "</table>\n";
    echo "</br>";
    oci_free_statement($stid);
}

CloseCon($conn);
