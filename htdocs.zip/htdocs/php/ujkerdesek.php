<?php

include 'connection.php';

if(!isset($_SESSION['id'])){
    echo "<script> location.href='bejelentkezes.php'; </script>";
    exit;
}

$conn = OpenCon();

$stid = oci_parse($conn, "SELECT KERDESSORAZON FROM KERDESSOR WHERE KERDESSOR.NEV = '" . $_SESSION['soqName'] . "'");

unset($_SESSION['soqName']);

oci_execute($stid);

$row = oci_fetch_array($stid, OCI_BOTH);

if (isset($row['KERDESSORAZON']))  {

    $_SESSION['soqId'] = $row['KERDESSORAZON'];
    $i = 1;
    $j = 1;

    echo '<form method="post" action="kerdessorok.php">';

    while ($i <= $_SESSION['count']) {

        echo '<div class="ujkerdesek">';
        echo '<fieldset>';
        echo '  Kérdés: <input type="text" name="question' . $i . '" required>
            <br><br>
            <input type="radio" id="' . $j . '" name="' . $i . '" value="' . $j . '" >
            <label for="' . $j . '">Ez a helyes: </label><br>
            1. Válasz: <input type="text" name="answear' . $j . '" required><br>';
        $j++;
        echo ' <input type="radio" id="' . $j . '" name="' . $i . '" value="' . $j . '" >
            <label for="' . $j . '">Ez a helyes: </label><br>
            2. Válasz: <input type="text" name="answear' . $j . '" required><br>';
        $j++;
        echo '  <input type="radio" id="' . $j . '" name="' . $i . '" value="' . $j . '" >
            <label for="' . $j . '">Ez a helyes: </label><br>
            3. Válasz: <input type="text" name="answear' . $j . '" required><br>';
        $j++;
        echo  '<input type="radio" id="' . $j . '" name="' . $i . '" value="' . $j . '" >
            <label for="' . $j . '">Ez a helyes: </label><br>
            4. Válasz: <input type="text" name="answear' . $j . '" required><br>';
        $j++;
        echo '</fieldset>';
        $i++;
    }
    unset($_SESSION['count']);
    echo '<button class="kerdessorbtn" type="submit">Kész</button>';
    echo '</form>';
    echo '</div>';


    CloseCon($conn);
}
