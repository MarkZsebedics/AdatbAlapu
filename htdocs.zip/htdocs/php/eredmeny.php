<?php

if(!isset($_SESSION['id'])) {
    echo "<script> location.href='bejelentkezes.php'; </script>";
    exit;
}

include 'connection.php';

$conn = OpenCon();

$stid = oci_parse($conn, "SELECT VALASZ.HELYESSEG AS helyesseg, VALASZ.VALASZAZON AS valasz,
KERDES.PONTSZAM AS pont, KERDES.KERDESSORAZON AS kerdessor FROM VALASZ, KERDES,
KERDESVALASZA WHERE VALASZ.VALASZAZON IN (SELECT VALASZAZON
FROM KERDESVALASZA) AND KERDES.KERDESAZON IN
(SELECT KERDESAZON FROM KERDESVALASZA)
AND VALASZ.VALASZAZON = KERDESVALASZA.VALASZAZON
AND KERDES.KERDESAZON = KERDESVALASZA.KERDESAZON");

oci_execute($stid);

$osszPont = 0;
$kerdessorID = 0;

while (($row = oci_fetch_array($stid, OCI_BOTH))!= false) {
    foreach($_POST as $key => $value){
        if ($value == $row['VALASZ'] && $row['HELYESSEG'] == "Y"){
            $osszPont += $row['PONT'];
        }
    }
    $kerdessorID = $row['KERDESSOR'];
}

echo '<div class="eredmeny">';
echo '<h1>Az elért pontszámod: ' . $osszPont . '</h1>';
echo '<h2>Gratulálok!</h2>';
echo "<a href='kerdesek.php?id= " . $_SESSION['kerdessor'] . "'>Kitöltöm újra</a><br>";
echo '<a class="edit" href="kerdessorok.php">Vissza a kérdéssorokhoz</a><br>';
echo '</div>';

$stid2 = oci_parse($conn, "INSERT INTO EREDMENY (FELHASZNALOAZON, KERDESSORAZON, DATUM, PONTSZAM)
VALUES (" .  $_SESSION['id'] . ", " . $kerdessorID . ", SYSDATE, " . $osszPont . ")");

oci_execute($stid2);

CloseCon($conn);