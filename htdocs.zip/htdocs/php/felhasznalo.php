<?php

include 'connection.php';

$conn = OpenCon();

$stid = oci_parse($conn, "SELECT FELHASZNALO.FELHASZNALOAZON AS id, FELHASZNALO.LAKHELYAZON, FELHASZNALO.SZULDATUM AS datum,
       FELHASZNALO.FELHASZNALONEV AS nev, FELHASZNALO.EMAIL AS email, LAKHELY.LAKHELYAZON, LAKHELY.MEGYE AS megye,
       LAKHELY.VAROS AS varos FROM FELHASZNALO, LAKHELY WHERE FELHASZNALO.LAKHELYAZON = LAKHELY.LAKHELYAZON AND
       FELHASZNALO.FELHASZNALOAZON = " . $_SESSION['id']);

oci_execute($stid);
$row = oci_fetch_array($stid, OCI_BOTH);

if(isset($row['ID'])){


    echo '<div class="felhasznalo">';
    echo '<h1>Felhasználó adatai: </h1>';
    echo '</div>';
    echo '<div class="felhasznalo">';

    echo 'Felhasználónév: ' . $row['NEV'] . '<br><br>' . 'Email-cím: ' . $row['EMAIL'] . '<br><br>';
    echo 'Lakhely: ' . $row['MEGYE'] . ' megye, ' . $row['VAROS'] . '<br><br>';
    echo 'Születési dátum: ' . $row['DATUM'] . '<br>';

    echo '</div>';

    echo '<div class="felhasznalo">';
    echo '<h1> Statisztikáid: </h1><br>';
    echo '</div>';

    echo '<div class="felhasznalo">';
    echo 'A legjobban sikerült kérdéssorod: <br>';


    $s = oci_parse($conn, "SELECT KERDESSOR.NEV AS nev, EREDMENY.PONTSZAM AS pont FROM KERDESSOR, EREDMENY
WHERE KERDESSOR.KERDESSORAZON = EREDMENY.KERDESSORAZON
AND EREDMENY.FELHASZNALOAZON = " . $_SESSION['id'] . " AND EREDMENY.PONTSZAM = (SELECT MAX(EREDMENY.PONTSZAM)
FROM EREDMENY WHERE EREDMENY.FELHASZNALOAZON = " . $_SESSION['id'] . ")");
    oci_execute($s);
    if($r = oci_fetch_array($s, OCI_BOTH)) {
        echo 'Kérdéssor neve: ' . $r['NEV'] . '<br>';
        echo 'Elért pontszám: ' . $r['PONT'] . '<br><br>';
    } else {
        echo 'Nincs még kitöltött kérdéssorod!<br><br>';
    }

    echo '</div>';

    echo '<div class="felhasznalo">';
    echo 'A legrosszabbul sikerült kérdéssorod: <br>';

    $s = oci_parse($conn, "SELECT KERDESSOR.NEV AS nev, EREDMENY.PONTSZAM AS pont FROM KERDESSOR, EREDMENY
WHERE KERDESSOR.KERDESSORAZON = EREDMENY.KERDESSORAZON
AND EREDMENY.FELHASZNALOAZON = " . $_SESSION['id'] . " AND EREDMENY.PONTSZAM = (SELECT MIN(EREDMENY.PONTSZAM)
FROM EREDMENY WHERE EREDMENY.FELHASZNALOAZON = " . $_SESSION['id'] . ")");
    oci_execute($s);
    if($r = oci_fetch_array($s, OCI_BOTH)) {
        echo 'Kérdéssor neve: ' . $r['NEV'] . '<br>';
        echo 'Elért pontszám: ' . $r['PONT'] . '<br><br>';
    } else {
        echo 'Nincs még kitöltött kérdéssorod!<br><br>';
    }


    echo '</div>';
    echo '<div class="felhasznalo">';
    echo 'A téma amiben a legtöbb pontot szerezted: <br>';

    $s = oci_parse($conn, "SELECT TEMA.NEV AS nev, sum(EREDMENY.PONTSZAM) AS pont FROM EREDMENY,
TEMA, KERDESSORTEMAJA WHERE EREDMENY.FELHASZNALOAZON = " . $_SESSION['id'] . " AND
EREDMENY.KERDESSORAZON = KERDESSORTEMAJA.KERDESSORAZON AND
KERDESSORTEMAJA.TEMAAZON = TEMA.TEMAAZON GROUP BY NEV ORDER BY PONT DESC");
    oci_execute($s);
    if($r = oci_fetch_array($s, OCI_BOTH)) {
        echo 'Téma neve: ' . $r['NEV'] . '<br>';
        echo 'Elért pontszám: ' . $r['PONT'] . '<br><br>';
    } else {
        echo 'Nincs még kitöltött kérdéssorod!<br><br>';
    }


    echo '</div>';
    echo '<div class="felhasznalo">';
    echo 'A téma amiben a legkevesebb pontot szerezted: <br>';

    $s = oci_parse($conn, "SELECT TEMA.NEV AS nev, sum(EREDMENY.PONTSZAM) AS pont FROM EREDMENY,
TEMA, KERDESSORTEMAJA WHERE EREDMENY.FELHASZNALOAZON = " . $_SESSION['id'] . " AND
EREDMENY.KERDESSORAZON = KERDESSORTEMAJA.KERDESSORAZON AND
KERDESSORTEMAJA.TEMAAZON = TEMA.TEMAAZON GROUP BY NEV ORDER BY PONT");
    oci_execute($s);
    if($r = oci_fetch_array($s, OCI_BOTH)) {
        echo 'Téma neve: ' . $r['NEV'] . '<br>';
        echo 'Elért pontszám: ' . $r['PONT'] . '<br><br>';
    } else {
        echo 'Nincs még kitöltött kérdéssorod!<br><br>';
    }

    echo '</div>';


    $s = oci_parse($conn, "SELECT avg(eredmeny.pontszam)  as atlag
 from felhasznalo left outer join eredmeny
 on felhasznalo.felhasznaloAzon = eredmeny.felhasznaloAzon
 where felhasznalo.felhasznaloAzon = " . $_SESSION['id'] .
 "group by felhasznalo.felhasznalonev");
    
    oci_execute($s);

    echo '<div class="ranglista">';
    echo '<div class="felhasznalo">';
    if($r = oci_fetch_array($s, OCI_BOTH)) {
        echo 'Atlagos pontszamod az osszes tesztre: ' . $r['ATLAG'] . '<br>';
    } else {
         echo 'Nincs még kitöltött kérdéssorod!<br><br>';
    }

    echo '</div>';
     $s = oci_parse($conn, "select count(eredmeny.kerdessorazon) 
 as DB
 from felhasznalo left outer join eredmeny
 on felhasznalo.felhasznaloAzon = eredmeny.felhasznaloAzon
 where felhasznalo.felhasznaloAzon = " . $_SESSION['id'] .
 "
 group by felhasznalo.felhasznalonev");
    
    oci_execute($s);
    echo '<div class="felhasznalo">';
    if($r = oci_fetch_array($s, OCI_BOTH)) {
        echo 'Osszesen kitoltott tesztjeid szama: ' . $r['DB'] . '<br>';
    } else {
        echo 'Nincs még kitöltött kérdéssorod!<br><br>';
    }

    $s = oci_parse($conn, "SELECT SUM(EREDMENY.PONTSZAM) AS pont FROM KERDESSOR, EREDMENY
WHERE KERDESSOR.KERDESSORAZON = EREDMENY.KERDESSORAZON
AND EREDMENY.FELHASZNALOAZON = " . $_SESSION['id']);
    oci_execute($s);
    if($r = oci_fetch_array($s, OCI_BOTH)) {
        echo 'Összes elért pontszám: ' . $r['PONT'] . '<br><br>';
    }

    echo '</div>';

} else {
    echo "<script> location.href='bejelentkezes.php'; </script>";
    exit;
}

CloseCon($conn);
