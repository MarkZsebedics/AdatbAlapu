<?php

include 'connection.php';

if(!isset($_SESSION['id'])){
    echo "<script> location.href='bejelentkezes.php'; </script>";
    exit;
}

$conn = OpenCon();
$err = '';

$stid = oci_parse($conn, "SELECT SZOVEG, BEJEGYZESAZON, FELHASZNALOAZON FROM FORUMBEJEGYZES WHERE BEJEGYZESAZON = " . $_GET["id"]);

if (oci_execute($stid)) {
    $row = oci_fetch_array($stid, OCI_BOTH);

    if( $_SESSION['id'] == $row['FELHASZNALOAZON']) {

        $stid2 = oci_parse($conn, "SELECT TEMAAZON, BEJEGYZESAZON FROM BEJEGYZESTEMAJA WHERE BEJEGYZESAZON = " . $_GET["id"]);

        if (oci_execute($stid2)) {
            $row2 = oci_fetch_array($stid2, OCI_BOTH);

            $stid = oci_parse($conn, "DELETE FROM BEJEGYZESTEMAJA WHERE BEJEGYZESAZON = " . $row2['BEJEGYZESAZON']);

            if (oci_execute($stid)) {

                $stid = oci_parse($conn, "DELETE FROM FORUMBEJEGYZES WHERE BEJEGYZESAZON = " . $row['BEJEGYZESAZON']);

                oci_execute($stid);

            }

        }
        $err = "Sikeresen törölted a bejegyzést!";
    } else {
        $err = "Csak a saját bejegyzésedet tudod törölni!";
    }

}


