<?php
include 'connection.php';

if(!isset($_SESSION['id'])){
    echo "<script> location.href='bejelentkezes.php'; </script>";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["theme"])) {
        $conn = OpenCon();

        $stid = oci_parse($conn, "SELECT NEV, TEMAAZON FROM TEMA WHERE NEV = '" . $_POST["theme"] . "'");
        oci_execute($stid);
        $row = oci_fetch_array($stid, OCI_BOTH);

        $stid2 = oci_parse($conn, "SELECT FELHASZNALONEV, FELHASZNALOAZON FROM FELHASZNALO WHERE FELHASZNALOAZON = " . $_SESSION['id']);
        oci_execute($stid2);
        $row2 = oci_fetch_array($stid2, OCI_BOTH);
        $username = $row2['FELHASZNALONEV'];

        $date = date('Y-m-d', strtotime($_POST['date']));

        if (!isset($row['NEV']))  {
            $stid = oci_parse($conn, "INSERT INTO TEMA (NEV) VALUES ('" . $_POST["theme"] . "')");

            if (oci_execute($stid) === TRUE) {
                $stid = oci_parse($conn, "SELECT MAX(TEMAAZON) AS id FROM TEMA");
                oci_execute($stid);
                $row = oci_fetch_array($stid, OCI_BOTH);
                $id = $row['ID'];

                $stid = oci_parse($conn, "INSERT INTO VERSENY (TEMAAZON, IDOPONT, KREATOR) VALUES (" . $id . ", TO_DATE('" . $date . "','yyyy-mm-dd'), '" . $username . "')");
                oci_execute($stid);
                echo "<script> location.href='versenyek.php'; </script>";
                exit;
            }
        } else {
            $stid = oci_parse($conn, "INSERT INTO VERSENY (TEMAAZON, IDOPONT, KREATOR) VALUES (" . $row['TEMAAZON'] . ", TO_DATE('" . $date . "','yyyy-mm-dd'), '" . $username . "')");
            oci_execute($stid);
            echo "<script> location.href='versenyek.php'; </script>";
            exit;
        }
        CloseCon($conn);
    }
}

