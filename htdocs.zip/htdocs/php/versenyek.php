<?php

include 'connection.php';

$conn = OpenCon();

$stid = oci_parse($conn, "SELECT VERSENY.VERSENYAZON AS id, VERSENY.TEMAAZON,
TEMA.TEMAAZON, TEMA.NEV AS tema, VERSENY.IDOPONT AS idopont,
VERSENY.KREATOR AS kreator FROM VERSENY, TEMA
WHERE VERSENY.TEMAAZON = TEMA.TEMAAZON ");

oci_execute($stid);
$i = 1;

echo '<div class="versenyek2">';
echo '<form method="post">';
echo '<fieldset>';
echo '<a>Hozz létre új versenyt: </a><br>';
echo '<a class="fill-in" href="ujverseny.php">Új verseny</a>';
echo '</fieldset>';
echo '</form>';
echo '</div>';

while (($row = oci_fetch_array($stid, OCI_BOTH))!= false){

    echo '<div class="versenyek">';
    echo '<form method="post">';
    echo '<fieldset>';
    echo $i . '. A verseny témája: ' . $row['TEMA'] . '<br><br>Kreátor: ' . $row['KREATOR'] . '<br><br>Időpontja: ' . $row['IDOPONT'] . '<br><br>';
    echo '<a class="fill-in" href="versenyek.php?id=' . $row['ID'] . '">Jelentkezés</a>';
    echo '</fieldset>';
    echo '</form>';
    echo '</div>';
    $i++;
}

if(isset($_GET['id']) && isset($_SESSION['id'])) {
    $stid = oci_parse($conn, "SELECT VERSENYAZON FROM FELHASZNALOVERSENYE WHERE VERSENYAZON = " . $_GET['id'] . " AND FELHASZNALOAZON = " . $_SESSION['id']);
    oci_execute($stid);
    $row = oci_fetch_array($stid, OCI_BOTH);

    if (isset($row['VERSENYAZON'])) {
        echo '<br><br>';
        echo '<a>Már jelentkeztél erre a versenyre! </a><br>';
    } else {
        $stid = oci_parse($conn, "INSERT INTO FELHASZNALOVERSENYE (VERSENYAZON, FELHASZNALOAZON) VALUES (" . $_GET['id'] . ", " . $_SESSION['id'] . ")");

        if (oci_execute($stid) === TRUE) {

            echo '<br><br>';
            echo '<a>A jelentkezés sikeres volt! </a><br>';
        }
    }

} elseif (isset($_GET['id']) && !isset($_SESSION['id'])) {
    echo "<script> location.href='bejelentkezes.php'; </script>";
    exit;
}

CloseCon($conn);
