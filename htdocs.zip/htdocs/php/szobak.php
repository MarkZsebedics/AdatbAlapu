<?php

include 'connection.php';

$conn = OpenCon();

$stid = oci_parse($conn, "SELECT SZOBAAZON, NEV, KREATOR FROM SZOBA");

oci_execute($stid);
$i = 1;

echo '<div class="szobak2">';
echo '<form method="post">';
echo '<fieldset class="soq">';
echo '<a>Hozz létre új szobát: </a><br>';
echo '<a class="fill-in" href="ujszoba.php">Új szoba</a>';
echo '</fieldset>';
echo '</form>';
echo '</div>';

while (($row = oci_fetch_array($stid, OCI_BOTH))!= false){

    echo '<div class="szobak">';
    echo '<form method="post">';
    echo '<fieldset class="soq">';
    echo $i . '. ' . $row['NEV'] . '<br><br>' . 'Kreátor: ' . $row['KREATOR'] . '<br><br>';
    echo '<a class="fill-in" href="szobak.php?id=' . $row['SZOBAAZON'] . '">Csatlakozás</a><br><br>';
    echo '<a class="fill-in" href="szobaupdate.php?id=' . $row['SZOBAAZON'] . '">Szoba módosítása</a>';
    echo '</fieldset>';
    echo '</form>';
    echo '</div>';
    $i++;

}

if(isset($_GET['id']) && isset($_SESSION['id'])) {
    $stid = oci_parse($conn, "SELECT SZOBAAZON FROM FELHASZNALOSZOBAJA WHERE SZOBAAZON = " . $_GET['id'] . " AND FELHASZNALOAZON = " . $_SESSION['id']);
    oci_execute($stid);
    $row = oci_fetch_array($stid, OCI_BOTH);

    if (isset($row['SZOBAAZON'])) {
        echo '<br><br>';
        echo '<a>Már tagja vagy ennek a szobának! </a><br>';
    } else {
        $stid = oci_parse($conn, "INSERT INTO FELHASZNALOSZOBAJA (SZOBAAZON, FELHASZNALOAZON) VALUES (" . $_GET['id'] . ", " . $_SESSION['id'] . ")");

        if (oci_execute($stid) === TRUE) {
            $stid = oci_parse($conn, "SELECT NEV FROM SZOBA WHERE SZOBA.SZOBAAZON = " . $_GET['id']);

            oci_execute($stid);
            $row = oci_fetch_array($stid, OCI_BOTH);

            echo '<br><br>';
            echo '<a>Csatlakoztál a "' . $row['NEV'] . '" szobához! </a><br>';
        }
    }

} elseif (isset($_GET['id']) && !isset($_SESSION['id'])) {
    echo "<script> location.href='bejelentkezes.php'; </script>";
    exit;
}

CloseCon($conn);