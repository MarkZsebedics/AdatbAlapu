<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Regisztráció</title>
    <meta name="author" content="Dobó Csenge, Tajti Sándor, Zsebedics Márk"/>
    <link rel="icon" href="images/logo.png"/>
    <link rel=stylesheet type="text/css" href="style/regisztracio_style.css" />
    <?php $usernameErr = $pwErr = $pw2Err = $equErr = $emailErr = $bornDateErr = $addressErr = "";
    $username = $pw2 = $pw = "";
    $email = "-";
    include "php/regisztracio.php"?>
</head>
<body>
<div class="container">
    <div class="container2">
        <div class="content">
            <h1>Regisztráció</h1>
            <p><span class="error">A * karakterrel jelölt mezők kitöltése kötelező!</span></p>
            <form method="POST" enctype="multipart/form-data">
                *Felhasználónév: <input type="text" name="username" required>
                <span class="error"><?php echo $usernameErr;?></span>
                <br><br>
                *Jelszó: <input type="password" name="pw" placeholder="" required>
                <span class="error"><?php echo $pwErr;?></span>
                <br><br>
                *Jelszó megerősítése: <input name="pw2" type="password" placeholder="" required>
                <span class="error"><?php echo $pw2Err;?></span>
                <span class="error"><?php echo $equErr;?></span>
                <br><br>
                *E-mail: <input type="email" name="email" required>
                <span class="error"><?php echo $emailErr;?></span>
                <br><br>
                *Születési dátum: <input type="date" name="bornDate">
                <span class="error"><?php echo $bornDateErr;?></span>
                <br><br>
                *Lakhely (Megye): <input type="text" name="addressM">
                <span class="error"><?php echo $addressErr;?></span>
                <br><br>
                *Lakhely (Város): <input type="text" name="addressV">
                <span class="error"><?php echo $addressErr;?></span>
                <br><br>
                <br><br>
                <button type="submit">Kész</button>
                <br><br>
            </form>
        </div>
    </div>
</div>
<div class="bejel"><a href="bejelentkezes.php" style="">Ha már regisztráltál, itt bejelentkezhetsz!</a></div>
<footer>Az alábbi Adatbázis alapú rendszerek gyakorlat projektmunka egy quiz webes felületének működését reprezentálja.<br> Készítette: Dobó Csenge, Tajti Sándor, Zsebedics Márk</footer>
</body>
</html>