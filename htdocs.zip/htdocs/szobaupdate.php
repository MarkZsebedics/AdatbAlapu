<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Új játék szobák</title>
    <meta name="author" content="Dobó Csenge, Tajti Sándor, Zsebedics Márk"/>
    <link rel="icon" href="images/logo.png"/>
    <link rel=stylesheet type="text/css" href="style/ujszoba_style.css" />
    <?php $roomNameErr = '';
    include "php/szobaupdate.php" ?>
</head>
<body>
<nav class="box" id="navigation">
    <ul>
        <li class="mainbtn"><a href = main.php target="_self">Főoldal</a></li>
        <li class="kerdessorbtn"><a href = kerdessorok.php target="_self">Quiz</a></li>
        <li class="szobabtn"><a href = szobak.php target="_self">Játék szobák</a></li>
        <li class="versenybtn"><a href = versenyek.php target="_self">Versenyek</a></li>
        <li class="forumbtn"><a href = forum.php target="_self">Forum</a></li>
        <li class="felhasznalobtn"><a href = felhasznalo.php target="_self">Profil</a></li>
        <li class="ranglistabtn"><a href = ranglista.php target="_self">Ranglista</a></li>
        <li class="logoutbtn"><a href = php/logout.php target="_self">Kijelentkezés</a></li>

    </ul>
</nav>
<div class="soq">
    <form method="post">
        Szoba neve: <input type="text" name="room_name" required>
        <span class="error"><?php echo $roomNameErr;?></span>
        <br><br>
        <button class="szobabtn" type="submit">Kész</button><br>
    </form>
</div>
<footer>Az alábbi Adatbázis alapú rendszerek gyakorlat projektmunka egy quiz webes felületének működését reprezentálja.<br> Készítette: Dobó Csenge, Tajti Sándor, Zsebedics Márk</footer>
</body>
</html>
