<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bejelentkezés</title>
    <meta name="author" content="Dobó Csenge, Tajti Sándor, Zsebedics Márk"/>
    <link rel="icon" href="images/logo.png"/>
    <link rel=stylesheet type="text/css" href="style/bejelentkezes_style.css" />
    <?php include "php/bejelentkezes.php" ?>
</head>
<body>
<div class="container">
    <div class="container2">
        <form action="" method="post" name="Login_Form" class="content">
            <table width="300 border="0" align="center" cellpadding="5" cellspacing="1" class="Table">
            <?php if(isset($msg)){?>
                <tr>
                    <td colspan="2" align="center" valign="top"><?php echo $msg;?></td>
                </tr>
            <?php } ?>
            <tr>
                <td colspan="2" align="left" valign="top"><h1>Bejelentkezés</h1></td>
            </tr>
            <tr>
                <td align="right" valign="top">Felhasználónév</td>
                <td><input name="userName" type="text" class="Input"></td>
            </tr>
            <tr>
                <td align="right">Jelszó</td>
                <td><input name="password" type="password" class="Input"></td>
            </tr>
            <tr>
                <td> </td>
                <td><input name="Submit" type="submit" value="Bejelentkezés"></td>
            </tr>

            </table>
        </form>
    </div>
</div>
<div class="reg"><a href="regisztracio.php" style="">Itt hozhatsz létre magadnak felhasználót!</a></div>
<footer>Az alábbi Adatbázis alapú rendszerek gyakorlat projektmunka egy quiz webes felületének működését reprezentálja.<br> Készítette: Dobó Csenge, Tajti Sándor, Zsebedics Márk</footer>
</body>
</html>